﻿using HorseRacingWebAPI.Models;

namespace HorseRacingWebAPI.Repository
{
    public interface IHorseBetRepository
    {
        public IList<HorseBet> GetHorseBets();
    }
}
