﻿using HorseRacingWebAPI.Models;

namespace HorseRacingWebAPI.Repository
{
    public class HorseBetRepository : IHorseBetRepository
    {

        public HorseBetRepository()
        {
            using (var context = new ApiContext())
            {
                var horseBets = new List<HorseBet>
                {
                new HorseBet
                {
                    Id=1,
                    Name="Black Caviar",
                    Bet= 100
                },
                 new HorseBet
                {
                    Id=2,
                    Name="Protectionist",
                    Bet=50
                },
                  new HorseBet
                {
                    Id=3,
                    Name="Green Moon",
                    Bet=50
                },
                   new HorseBet
                {
                    Id=4,
                    Name="Makybe Diva",
                    Bet=50
                },
                   new HorseBet
                {
                    Id=5,
                    Name="Old Rowley",
                    Bet=50
                },
                      new HorseBet
                {
                    Id=6,
                    Name="Shocking",
                    Bet=80
                },
                       new HorseBet
                {
                    Id=7,
                    Name="Shocking",
                    Bet=30
                },
                        new HorseBet
                {
                    Id=8,
                    Name="Delta Blues",
                    Bet=70
                }
                };
                context.HorseBets.AddRange(horseBets);
                context.SaveChanges();
            }
        }

        public IList<HorseBet> GetHorseBets()
        {
            using (var context = new ApiContext())
            {
                return context.HorseBets.ToArray();                
                
            }
        }
    }
}
