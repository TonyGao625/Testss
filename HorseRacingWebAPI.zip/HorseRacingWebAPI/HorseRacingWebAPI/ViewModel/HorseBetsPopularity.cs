﻿namespace HorseRacingWebAPI.ViewModel
{
    public class HorseBetsPopularity
    {
        public int Number { get; set; }
        public string Name { get; set; }

        public int? TotalAmountMoney { get; set; }

        public int? PercentageOfTotal { get; set; }
    }
}
