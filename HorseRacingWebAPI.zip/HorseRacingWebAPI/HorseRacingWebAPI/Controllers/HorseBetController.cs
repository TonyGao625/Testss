﻿using HorseRacingWebAPI.Models;
using HorseRacingWebAPI.Repository;
using HorseRacingWebAPI.ViewModel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace HorseRacingWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class HorseBetController : ControllerBase
    {
        readonly IHorseBetRepository _horseBetRepository;
        public HorseBetController(IHorseBetRepository horseBetRepository)
        {
            _horseBetRepository = horseBetRepository;
        }


        [HttpGet]
        public ActionResult<List<HorseBetsPopularity>> GetHorsesByPopularity()
        {

            var horseBets = _horseBetRepository.GetHorseBets();
            var horseBetsByPopularity = from horseBet in horseBets
                                        group horseBet by horseBet.Id into h
                                        select new HorseBetsPopularity
                                        {
                                            Number = h.First().Id,
                                            Name = h.First().Name,
                                            TotalAmountMoney = h.Sum(t => t.Bet)
                                        };
            var totalBets= horseBets.Sum(t => t.Bet);
            horseBetsByPopularity = from horseBet in horseBetsByPopularity.OrderByDescending(x=>x.TotalAmountMoney)
                                    select new HorseBetsPopularity
                                    {
                                        Number = horseBet.Number,
                                        Name = horseBet.Name,
                                        TotalAmountMoney = horseBet.TotalAmountMoney,
                                        PercentageOfTotal = (horseBet.TotalAmountMoney/totalBets)
                                    };
            return Ok(horseBetsByPopularity);
        }
    }
}
