﻿using Microsoft.EntityFrameworkCore;

namespace HorseRacingWebAPI.Models
{
    public class ApiContext : DbContext
    {
        protected override void OnConfiguring
       (DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseInMemoryDatabase(databaseName: "InMemoryDb");
        }
        public DbSet<HorseBet> HorseBets { get; set; }
    }
}
